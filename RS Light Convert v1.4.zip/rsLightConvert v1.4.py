import c4d

def C4dOr2rs(i,type,lightlist,name):  
	if type==5102:       	
        	#get light info     	
            i[c4d.ID_BASEOBJECT_GENERATOR_FLAG] = 0
            lightType = i[c4d.LIGHT_TYPE]
            color = i[c4d.LIGHT_COLOR]
            intensity = i[c4d.LIGHT_BRIGHTNESS]
            shadow = i[c4d.LIGHT_SHADOWTYPE_VIRTUAL]
            mode = i[c4d.LIGHT_EXCLUSION_MODE]
            objlist = i[c4d.LIGHT_EXCLUSION_LIST]

            #create rs light
            rslt = c4d.BaseObject(1036751)

            #set light type
            rslt[c4d.REDSHIFT_LIGHT_TYPE] = lightlist[lightType]

            #set color and intensity
            if(lightType != 9):
            	rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR] = color
            	rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY] *= intensity
            else:
            	rslt[c4d.REDSHIFT_LIGHT_IES_MULTIPLIER] *= intensity

            #set value
            if(lightType == 8):
            	x = i[c4d.LIGHT_AREADETAILS_SIZEX]
            	y = i[c4d.LIGHT_AREADETAILS_SIZEY]
            	#shape = 
            	rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEX] = x
            	rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEY] = y
            if(shadow == 0):
                rslt[c4d.REDSHIFT_LIGHT_SHADOW] = 0
            rslt[c4d.REDSHIFT_LIGHT_EXCLUSION_MODE] = mode
            rslt[c4d.REDSHIFT_LIGHT_EXCLUSION_LIST] = objlist

            doc.InsertObject(rslt,i)
	        #read tag
            tags = i.GetTags()
            #copy tag
            for t in tags:
                if t.GetType()!=1029526:
                    rslt.InsertTag(t)

            rslt.SetName(name)
            tagtype = []
            for t in tags:
            	tagtype.append(t.GetType())
	        
	        #orDaylight to rsSunSky
            if 1029754 in tagtype:	
            	#delete rslt
                doc.SetActiveObject(rslt)
                c4d.CallCommand(100004787)
                #create sun sky rig
                sun = c4d.BaseObject(1036751)
                sky = c4d.BaseObject(1036754)
                sun[c4d.REDSHIFT_LIGHT_TYPE] = 7
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_SUN] =sun
                doc.InsertObject(sky,i)
                doc.InsertObject(sun,sky)
                sky.SetName("Physical Sky")
            #orAreaLight
            for t in tags:
                if t.GetType()==1029526:
                    rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLORMODE] = 1
                    rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_TEMPERATURE] = t[c4d.LIGHTTAG_BB_TEMPERATURE]
                    rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY] = t[c4d.LIGHTTAG_POWER]/100
                    rslt[c4d.REDSHIFT_LIGHT_AFFECTS_DIFFUSE] = t[c4d.LIGHTTAG_VISIBLE_ON_DIFFUSE]
                    rslt[c4d.REDSHIFT_LIGHT_AFFECTS_SPECULAR] = t[c4d.LIGHTTAG_VISIBLE_ON_SPECULAR]
                    #delete tag
                    #doc.SetActiveObject(None)
                    #doc.SetActiveTag(t)
                    #c4d.CallCommand(100004787)

	                
        #Physical Light
        elif type==1011146:
        	i[c4d.ID_BASEOBJECT_GENERATOR_FLAG] = 0
                sun = c4d.BaseObject(1036751)
                sky = c4d.BaseObject(1036754)
                sun[c4d.REDSHIFT_LIGHT_TYPE] = 7
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_SUN] =sun
                doc.InsertObject(sky,i)
                doc.InsertObject(sun,sky)
                sky.SetName("Physical Sky")

        #Dome Light
        elif type==5105:
        	i[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = 1
        	dome = c4d.BaseObject(1036751)
        	dome[c4d.REDSHIFT_LIGHT_TYPE] = 4
        	sky = c4d.BaseObject(1036754) 

        	#get tag info
        	tags = i.GetTags()
                if len(tags)>0:
                    tag = tags[0]
                else:
                    tag = i
            #convert octane sky/hdr
        	if tag.GetType()==1029643:
        		doc.InsertObject(dome,i)               
        		#get env info
        		map = tag[c4d.ENVIRONMENTTAG_TEXTURE][c4d.IMAGETEXTURE_FILE]
        		power = (tag[c4d.ENVIRONMENTTAG_POWER]-1)*8
        		#set dome info
        		dome[c4d.REDSHIFT_LIGHT_DOME_TEX0,c4d.REDSHIFT_FILE_PATH] = map
        		dome[c4d.REDSHIFT_LIGHT_DOME_EXPOSURE0] = power
        		#dome type
        		dometype = tag[c4d.ENVTAG_SLOT]               
        		if dometype==1:
        			dome[c4d.REDSHIFT_LIGHT_DOME_BACKGROUND_ENABLE]=tag[c4d.ENVTAG_VIS_BACKPLATE]
        			dome[c4d.REDSHIFT_LIGHT_AFFECTS_DIFFUSE]=0
        			dome[c4d.REDSHIFT_LIGHT_AFFECTS_SPECULAR]=tag[c4d.ENVTAG_VIS_REFLECT]
        			dome[c4d.REDSHIFT_LIGHT_SHADOW]=0

            #convert c4d sky/hdr
    		if tag.GetType()==5616:
        		mat = tag[c4d.TEXTURETAG_MATERIAL]
	        	if(mat[c4d.MATERIAL_USE_LUMINANCE]==1):
	        		doc.InsertObject(dome,i)
                    
	        		if(mat[c4d.MATERIAL_LUMINANCE_SHADER]!= None):
	        			tex = mat[c4d.MATERIAL_LUMINANCE_SHADER][c4d.BITMAPSHADER_FILENAME]
	        			dome[c4d.REDSHIFT_LIGHT_DOME_TEX0,c4d.REDSHIFT_FILE_PATH] = tex

	        	elif(mat[c4d.MATERIAL_USE_COLOR]==1):
	        		doc.InsertObject(sky,i)                       
	        		col = mat[c4d.MATERIAL_COLOR_COLOR]
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_GROUND_COLOR] = col
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_NIGHT_COLOR] = col
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_REFLECTION_ENABLE] = 0
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_REFRACTION_ENABLE] = 0
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_GI_ENABLE] = 0
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_HAZE] = 0
	        		sky[c4d.REDSHIFT_SKY_PHYSICALSKY_OZONE] = 0


def Ar2rs(i,lightType,lightlist,areaType,name):
    #get light info
    i[c4d.ID_BASEOBJECT_GENERATOR_FLAG] = 0
    #create rs light
    rslt = c4d.BaseObject(1036751)
    
    if i.GetType()!=1034624:
        #set light type
        rslt[c4d.REDSHIFT_LIGHT_TYPE] = lightlist[lightType]
        
        doc.InsertObject(rslt,i)
        #rslt.SetName(name)

        if lightlist[lightType]==3:
            rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_GEOMETRY] = areaType
        rslt.SetName(name)

    #arealight
    if lightType==1218397465:
        #rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEX]=i[c4d.C4DAI_QUAD_LIGHT_WIDTH]
        #rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEY]=i[c4d.C4DAI_QUAD_LIGHT_HEIGHT]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[2010942260]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]*=i[67722820]
    #disklight
    if lightType==998592185:
        #rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEX]=i[c4d.C4DAI_DISK_LIGHT_RADIUS]
        #rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_SIZEY]=i[c4d.C4DAI_DISK_LIGHT_RADIUS]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[2014459500]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]*=i[356519964]
    #cylnderlight
    if lightType==1944046294:
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[557215133]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]*=i[1822316437]

    #meshlight
    if lightType==804868393:
        mesh = i[1754618916]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_AREA_MESH] = mesh
    #distantlight
    if lightType==1381557517:
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[47856576]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]*=i[101548232]
    #photometriclight
    if lightType==1980850506:
        rslt[c4d.REDSHIFT_LIGHT_IES_COLOR]=i[2101923881]
        rslt[c4d.REDSHIFT_LIGHT_IES_MULTIPLIER]*=i[2029461537]
        rslt[c4d.REDSHIFT_LIGHT_IES_PROFILE,c4d.REDSHIFT_FILE_PATH]=i[1413133543]
    #pointlight
    if lightType==381492518:
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[1458609997]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]=i[1920590149]*100
    #spotlight
    if lightType==876943490:
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLOR]=i[1823117041]
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_INTENSITY]=i[1389690135]*250000
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_SPOT_CONE_ANGLE]=i[1541806011]/57.296
        rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_SPOT_CONE_FALLOFF_ANGLE]=i[1015434032]/57.296

    #skydome deldete
    if lightType==2054857832:
        doc.SetActiveObject(rslt)
        c4d.CallCommand(100004787)
    #Sky/skydome 
    if i.GetType()==1034624 or lightType==2054857832:
        if i[c4d.C4DAIS_SKY_TYPE]==0 or lightType==2054857832:
            shaderLinkData = i[9988000][268620635]
            shaderLinkType = shaderLinkData[101]

            # color
            if shaderLinkType == 1:
                color = shaderLinkData[102]
                #create sky
                sky = c4d.BaseObject(1036754)
                doc.InsertObject(sky,i)                       
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_GROUND_COLOR] = color
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_NIGHT_COLOR] = color
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_REFLECTION_ENABLE] = 0
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_REFRACTION_ENABLE] = 0
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_GI_ENABLE] = 0
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_HAZE] = 0
                sky[c4d.REDSHIFT_SKY_PHYSICALSKY_OZONE] = 0
            # texture
            elif shaderLinkType == 2:
                map = shaderLinkData[103][c4d.BITMAPSHADER_FILENAME]
                #create dome
                dome = c4d.BaseObject(1036751)
                dome[c4d.REDSHIFT_LIGHT_TYPE] = 4
                dome[c4d.REDSHIFT_LIGHT_DOME_TEX0,c4d.REDSHIFT_FILE_PATH] = map
                doc.InsertObject(dome,i)
                dome.SetName("Dome Light")
                
            # shader network
            elif shaderLinkType == 3:
                material = shaderLinkData[104]
                dome = c4d.BaseObject(1036751)
                dome[c4d.REDSHIFT_LIGHT_TYPE] = 4
                doc.InsertObject(dome,i)
        else:
            rslt[c4d.ID_BASEOBJECT_GENERATOR_FLAG]=0
            sun = c4d.BaseObject(1036751)
            rssky = c4d.BaseObject(1036754)
            sun[c4d.REDSHIFT_LIGHT_TYPE] = 7
            rssky[c4d.REDSHIFT_SKY_PHYSICALSKY_SUN] =sun
            doc.InsertObject(rssky,i)
            doc.InsertObject(sun,rssky)
            rssky.SetName("Physical Sky")


    #temperature color
    if i[c4d.C4DAI_LIGHT_COMMON_USE_TEMPERATURE]==1:
        if lightType==1980850506:
            rslt[c4d.REDSHIFT_LIGHT_IES_COLORMODE] = 1
            rslt[c4d.REDSHIFT_LIGHT_IES_TEMPERATURE] = i[c4d.C4DAI_LIGHT_COMMON_TEMPERATURE]
        else:
            rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_COLORMODE] = 1
            rslt[c4d.REDSHIFT_LIGHT_PHYSICAL_TEMPERATURE]=i[c4d.C4DAI_LIGHT_COMMON_TEMPERATURE]

    rslt[c4d.REDSHIFT_LIGHT_EXCLUSION_MODE] = i[c4d.C4DAI_LIGHT_COMMON_EXCLUSION_MODE]
    rslt[c4d.REDSHIFT_LIGHT_EXCLUSION_LIST] = i[c4d.C4DAI_LIGHT_COMMON_EXCLUSION_LIST]

def setRenderData():
    rdata = doc.GetActiveRenderData()
    rdata[c4d.RDATA_RENDERENGINE]=1036219
    redshift = 1036219
    
    videopost = rdata.GetFirstVideoPost()
    while videopost:
        if videopost.GetType() == redshift:
            break
        videopost = videopost.GetNext()
    
    prim = videopost[c4d.REDSHIFT_RENDERER_PRIMARY_GI_ENGINE]
    second = videopost[c4d.REDSHIFT_RENDERER_SECONDARY_GI_ENGINE]
    if prim==0 and second==0:
        print "Set GI Engine to BF"
        videopost[c4d.REDSHIFT_RENDERER_PRIMARY_GI_ENGINE] = 4
        videopost[c4d.REDSHIFT_RENDERER_SECONDARY_GI_ENGINE] = 4

def deleteLights(lights):
    for i in lights:
        type = i.GetType()
        types = [5102,1011146,5105,1030424,1034624]
        if type in types:
            doc.SetActiveObject(i)
            c4d.CallCommand(1019951, 1019951)

def main():
    lights =doc.GetActiveObjects(1)
    doc.StartUndo()
    
    for i in lights:
        name = i.GetName()
    	type = i.GetType()
        #c4d light/octane light
    	if(type==5102 or type==1011146 or type==5105):
    		#Point,Spot,Inf,Area,Ies Light
    		lightlist = {0:1,1:2,3:0,8:3,9:5}
    		C4dOr2rs(i,type,lightlist,name)
        #arnold light
        if(type==1030424 or type==1034624):
            #Point,Spot,Inf,Area,Mesh,Disk,Cylinder,IES,Sky
            arlist = {381492518:1,876943490:2,1381557517:0,1218397465:3,804868393:3,998592185:3,1944046294:3,1980850506:5,2054857832:4}
            arealist = {1218397465:0,998592185:1,1944046294:3,804868393:4}
            lightType = i[c4d.C4DAI_LIGHT_TYPE]

            areaType = 0
            if lightType in arealist:
                areaType = arealist[lightType]
            Ar2rs(i,lightType,arlist,areaType,name)
    
    #deleteLights(lights)
    setRenderData()

    c4d.EventAdd()
    doc.EndUndo() 

if __name__=='__main__':
    main()
