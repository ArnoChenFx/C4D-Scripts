import c4d

def main():
    objs = doc.GetActiveObjects(0)
    #c4d.CallCommand(431000081)
    #create takes
    for i in objs:
        takeData = doc.GetTakeData()
        name = i.GetName()
        
        newTake = takeData.AddTake(name, None, None)
    
    #loop all take        
    mainTake = takeData.GetMainTake()
    take = mainTake.GetDown()

    while take is not None:
        if take.GetName()!="Main":
            takeData = doc.GetTakeData()
            takeData.SetCurrentTake(take)
            take.SetChecked(True)
            #set parm
            visiable = c4d.DescID(c4d.DescLevel(c4d.ID_BASEOBJECT_VISIBILITY_EDITOR, c4d.DTYPE_REAL, 0))
            render = c4d.DescID(c4d.DescLevel(c4d.ID_BASEOBJECT_VISIBILITY_RENDER, c4d.DTYPE_REAL, 0))
            newValue1 = 1#off
            newValue2 = 2#on
            for obj in objs:
                if obj.GetName()==take.GetName():
                    overrideNode = take.FindOrAddOverrideParam(takeData, obj, visiable, newValue2)
                    overrideNode = take.FindOrAddOverrideParam(takeData, obj, render, newValue2)
                else:
                    overrideNode = take.FindOrAddOverrideParam(takeData, obj, visiable, newValue1)
                    overrideNode = take.FindOrAddOverrideParam(takeData, obj, render, newValue1)
                #override
                overrideNode.UpdateSceneNode(takeData, visiable)
                overrideNode.UpdateSceneNode(takeData, render)
                c4d.EventAdd()
                
        print take.GetName()
        take = take.GetNext()
    
    c4d.EventAdd()

if __name__=='__main__':
    main()